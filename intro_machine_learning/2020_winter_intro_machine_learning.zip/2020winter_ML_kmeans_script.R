library(cluster)

#load iris data
data(iris)
head(iris)

#retrieve variables
data=iris[,1:4]

#choose k
library(factoextra)
fviz_nbclust(x = data,FUNcluster = kmeans, method = 'wss' )

#train kmeans
fit <- kmeans(data, centers= 3, nstart=25, algorithm ="Lloyd", iter.max=100)
fit$cluster

#visualize clusters
fviz_cluster(fit, data = data, palette = c("#00AFBB","#2E9FDF", "#E7B800", "#FC4E07"), ggtheme = theme_minimal())
