library(class)
library(caret)

#load iris data
data(iris)
head(iris)

#shuffle iris data
iris=iris[sample(1:length(iris[,1]),length(iris[,1])),]
head(iris)

#assign training data and test data
train_index=1:round(length(iris[,1])*0.7)
train_data=iris[train_index,1:4]
train_label=as.character(iris[train_index,5])

test_data=iris[-train_index,1:4]
test_label=as.character(iris[-train_index,5])

#find the best k using cross validation 
caret_fit <- train(train_data, train_label, method = "knn", trControl = trainControl(method="cv",number = 10))

#plot accuracy and k
plot(caret_fit)

#predict labels
prediction<- predict(caret_fit, newdata = test_data)

#check the prediction result
summary(prediction)

#tablulatize prediction vs observed value
tb <- table(prediction,test_label)
tb

#calculate accuracy
accuracy <- function(x){sum(diag(x)/(sum(rowSums(x)))) * 100}
accuracy(tb)
