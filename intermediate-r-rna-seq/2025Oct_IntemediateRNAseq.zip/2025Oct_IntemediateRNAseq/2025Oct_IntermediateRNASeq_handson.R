#---
#title: "Intermediate RNA-seq workshop R script"
#author: "Michela Traglia"
#---


#---set the path of your folder
setwd("~/Downloads/2025Oct_IntermediateRNAseq")

#---upload the library
#----------------------------
#install.packages("tidyverse")
library(tidyverse) #working with dataframes
#----------------------------
#install.packages("pheatmap")
library(pheatmap) #heatmaps
#----------------------------
#install.packages("magrittr")
library(magrittr) #manipulate dataframes using pipes
#----------------------------
#install.packages("statmod") 
library(statmod) #dependency for edgeR
#----------------------------
#if (!requireNamespace("BiocManager", quietly = TRUE))
#  install.packages("BiocManager")
#----------------------------
#BiocManager::install("edgeR")
library(edgeR)#R package to perform DEG analysis
#alternative use 
#DESeq BiocManager::install("DESeq2") 
#browseVignettes("DESeq2")
#----------------------------
#BiocManager::install("org.Mm.eg.db")
library(org.Mm.eg.db)#matching and converting the gene IDs using mouse db
#----------------------------
#install.packages("ggplot2")
library(ggplot2) #visualization
#----------------------------


#----------------------------
# 1. Load and organize data.
#----------------------------

# Upload the phenotype file and the raw count matrix

phenotype_info_file <- "targets.txt"
raw_counts_file <- "GSE60450_Lactation-GenewiseCounts.txt.gz"

#12 samples and 6 categories
targets <- read.delim(phenotype_info_file, stringsAsFactors=FALSE) #delimited files, defaulting to the TAB character for the delimiter
  
View(targets)

# Create a group variable to assign "cell type.status" to each sample

group <- paste(targets$CellType, targets$Status, sep = ".")
group <- as.factor(group)
#alternative
#group <- targets %$% paste(CellType, Status, sep = ".") %>% factor()

group

#Length of a gene is the total number of bases in exons and UTRs for that gene.
GenewiseCounts <- read.delim(raw_counts_file , row.names="EntrezGeneID")
head(GenewiseCounts,1)

# rename the columns to match the target IDs - phenotype_info_file rownames 
colnames(GenewiseCounts)=substring(colnames(GenewiseCounts), 1, 7)

#colnames(GenewiseCounts) %<>% substring(.,1,7)

head(GenewiseCounts,1)



#------------------------
# 2. MA plots
#------------------------

# Let's visualize two technical replicates, the two Basal virgin samples
# using a MA plot. Adding a pseudocount equal to 1 to transform the counts to log2

two_samples <- GenewiseCounts[, c(2, 3)] + 1 #2, 3: Replicate samples 12
two_samples <- log2(two_samples)
head(two_samples)

#alternative:
#two_samples <- GenewiseCounts[, c(2, 3)] %>% 
#  add(., 1) %>%
#  log2()



# Saving a data frame with M and A to be plotted
# M is the difference between the two samples (logFC) and A is the average expression between the two samples. 
plotData <- data.frame(M = two_samples[, 1] - two_samples[, 2],
                       A = (two_samples[, 1] + two_samples[, 2])/2)

#log fold-change versus mean expression between two groups/sampels
#pdf("step02_MA_plots_pre_normalization_plots.pdf")
ggplot(plotData, aes(x = A, y = M)) +
  geom_point() +
  geom_smooth()

# Let's visualize two biological replicates, one Basal virgin sample and one Luminal lactating sample
two_samples <- GenewiseCounts[, c(2, 12)] + 1 
two_samples <- log2(two_samples)
head(two_samples)

# M is the difference between the two samples (logFC) and A is the average expression between the two samples. 
# Saving a data frame with M and A to be plotted
plotData <- data.frame(M = two_samples[, 1] - two_samples[, 2],
                       A = (two_samples[, 1] + two_samples[, 2])/2)

#log fold-change versus mean expression between two treatments
ggplot(plotData, aes(x = A, y = M)) +
  geom_point() +
  geom_smooth()

#dev.off()
#------------------------
# 3. Create DGElist object and retrieve gene symbols.
#------------------------
# Create e DGE object including the counts the celltype.status and the gene names and length

y <- DGEList(counts = GenewiseCounts[,-1], 
             group = group,
             genes = GenewiseCounts[,1,drop=FALSE]) #drop=FALSE keeps the same structure

# convert gene from ENTREZID to SYMBOL
y$genes$Symbol <- mapIds(org.Mm.eg.db,
                         keys = rownames(y),
                         keytype="ENTREZID", 
                         column="SYMBOL")

View(y)
head(y)



#------------------------
# 4. Independent filtering.
#------------------------

#Filter genes whose symbols are not found.
dim(y)
keep <- !is.na(y$genes$Symbol) 

head(keep)
table(keep)

y <- y[keep, ]

dim(y)

# It is not possible to make reliable inference for genes if gene count is too small

# https://f1000research.com/articles/5-1438 :
# As a rule of thumb, we require that a gene have a count of at least 10~15 in at least some libraries
# filter on count-per-million (CPM) values so as to avoid favoring genes that are expressed in larger 
# libraries over those expressed in smaller libraries

# CPM is equal to the number of reads x 10^6 divided by the total number of mapped reads
# We set 10 as counts cutoff to remove low expressed genes
# CPM = number of counts x 10^6 divided by the total number of mapped reads
# number of counts = 10 

minimum_counts_reqd <- 10
total_reads <- median(y$samples$lib.size)
cpm_cutoff = minimum_counts_reqd * 10^6 / total_reads
cpm_cutoff = round(cpm_cutoff, 1)
cpm_cutoff

#or 
#cutoff <- y$samples$lib.size %>% 
#  median() %>% 
#  divide_by(10^6) %>% 
#  divide_by(minimum_counts_reqd, .) %>% #check
#  round(1)

#... or simply set cutoff to 0.5

# keeping genes above the cutoff  

keep <- cpm(y, prior.count=1)
keep = keep > cpm_cutoff
#in at least two libraries
keep = rowSums(keep)
keep = keep >= 2

head(keep)

#or
#keep <- cpm(y) %>% #counts per million
#  is_greater_than( cutoff) %>%
#  rowSums() %>%
#  is_weakly_greater_than( 2)

#subsetting the DGE object
y <- y[keep, , keep.lib.sizes=FALSE] # keep.lib.sizes=FALSE: the library sizes to be recomputed after the filtering



#-------------------------
# 5. Normalizing the counts.
#-------------------------

y$samples

# normalize for RNA composition by a set of scaling factors 
# that minimize the log-fold changes between the samples for most genes
y <- calcNormFactors(y)
y$samples

#"A normalization factor below one indicates that a small number of high count genes 
#...are monopolizing the sequencing, causing the counts for other genes to be lower 
#...than would be usual given the library size." Chen et al., 2016
#Looks like L.lactating samples contain a number of very highly upregulated genes.



# Plot the normalization factors by sample.
# Intuitively, we should expect similar adjustments for similar samples.
#pdf("step05_Normalization_factors_pre_post_normalization.pdf")
ggplot(cbind(y$samples, replicate = factor(1:2)), 
       aes(x = group, y = norm.factors, fill = replicate)) +
  geom_col(position = position_dodge())
#dev.off()





#------------------------
# 6. Exploratory visualizations of samples
#------------------------

# MDS plot - the distance between two points is 
# the leading log2FC: the root-mean-square average of the top largest log2-fold-changes between those two samples

#pdf("step06a_MDSplot.pdf")
pch <- c(0,1,2,15,16,17)
colors <- rep(c("darkgreen", "red", "blue"), 2)
plotMDS(y, col=colors[group], pch=pch[group], gene.selection = "common")
legend("top", legend=levels(group) %>% substr(1, 3), 
       pch=pch, col=colors, ncol=2, cex = 0.5)
#dev.off()


#PCA plot using logCPM
cpm <- cpm(y, log = TRUE)
View(cpm)
#calcalting the variance across samples for each gene
rv <- apply(cpm,1,var) 

#Select genes with highest variance.
keep <- order(rv, decreasing = TRUE)[1:500]
selected <- cpm[keep, ] %>% t()

#Transpose is needed to ensure that each row is a vector of CMP across genes - rows are samples
pca <- prcomp(selected, scale=T, center = T)

str(pca)
View(pca$x)

head(as.data.frame(pca$x)$PC1) 


summary(pca)
str(summary(pca))

pc1_var <- round(summary(pca)$importance[2,1] * 100)
pc2_var <- round(summary(pca)$importance[2,2] * 100)


#or
# stddev <- pca$sdev
#pc1_var <- round(100*stddev[1]^2/sum(stddev^2))
#pc2_var <- round(100*stddev[2]^2/sum(stddev^2))

PlotData <- data.frame(PC1 = as.data.frame(pca$x)$PC1, PC2 = as.data.frame(pca$x)$PC2)
PlotData <- targets[, c("CellType", "Status")] %>%
  cbind(PlotData, .)

head(PlotData)

#pdf("step06b_PCA_plot.pdf")
ggplot(PlotData, aes(x=PC1, y=PC2, color=CellType, shape=Status)) + 
  geom_point(size=4.5) +  
  xlab(paste("PC1:", pc1_var, "% variance")) + 
  ylab(paste("PC2:", pc2_var, "% variance"))
#dev.off()


#--------------------
# 7. Fitting the model.
#--------------------

# creating the design matrix
design <- model.matrix(~ 0 + group) %>%   
             set_colnames(levels(group))
design

#setting the intercept will set the first level as reference group but we are interested in 
# complicated comparisons (or contrast)
#design <- model.matrix(~ 1 + group)

#design


# edgeR uses the negative binomial (NB) distribution to model the read counts for each gene in each sample. 
#  Dispersion estimates 
y <- estimateDisp(y, design, robust=TRUE) 

#Biological coefficient of variation to estimate the sample to sample variability
# y axis is the square-root dispersion
# the NB dispersions tend to be higher for genes with very low counts
#pdf("step07a_BCV_plot.pdf")
plotBCV(y)
#dev.off()
fit <- glmQLFit(y, design, robust=TRUE)  #Empirical Bayes estimates need to be controlled for the 
#possibility of outlier genes with exceptionally large or small individual dispersions 

# DGEGLM object with the estimated values of the GLM coefficients for each gene. 
# It also contains a number of empirical Bayes (EB) statistics including 
# the QL dispersion trend, 
# the squeezed QL dispersion estimates and
# the prior degrees of freedom (df). 
head(fit$coefficients)

#Visualize the dispersion: the raw QL dispersion estimates are squeezed towards a global trend
# to reduce the uncertainty of the estimates and improves testing power.
#pdf("step07b_QL_dispersion_plot.pdf")
plotQLDisp(fit) 
#dev.off()


#--------------------
# 8. Hypothesis testing
#--------------------

#----------------------------
#Example 1: Hypothesis: The mean expression of B.lactating is different from the mean expression of B.pregnant.
B.LvsP <- makeContrasts(B.lactating-B.pregnant, levels=design)
res <- glmQLFTest(fit, contrast=B.LvsP)
topTags(res)
is.de <- decideTests(res)
summary(is.de)
#Down  -1
#NotSig  0
#Up  1

#pdf("step08_Example_1_contrast_plot.pdf")
plotMD(res, status=is.de, values=c(1,-1), col=c("red","blue"),
       legend="topright")
#dev.off()
#----------------------------
#Example 2: Hypothesis: The mean expression of B.lactating is different from the mean expression of B.pregnant and 
#  the log2-fold-changes are significantly greater than 1.5
B.LvsP <- makeContrasts(B.lactating-B.pregnant, levels=design)
res <- glmTreat(fit, contrast=B.LvsP, lfc=log2(1.5))
topTags(res)
is.de <- decideTests(res)
summary(is.de)
#pdf("step08_Example_2_lfc_cutoff_contrast_plot.pdf")
plotMD(res, status=is.de, values=c(1,-1), col=c("red","blue"),
       legend="topright")
#dev.off()
#----------------------------
#Example 3: Hypothesis: The change in expression between lactating and pregnant mice is the same for basal cells as it is for luminal cells
con <- makeContrasts(
  (L.lactating-L.pregnant)-(B.lactating-B.pregnant),
  levels=design)
res <- glmQLFTest(fit, contrast=con)
topTags(res)
is.de <- decideTests(res)
summary(is.de)
#pdf("step08_Example_3_contrast_plot.pdf")
plotMD(res, status=is.de, values=c(1,-1), col=c("red","blue"),
       legend="topright")
#dev.off()
#----------------------------
#Example 4: Hypothesis : Comparing virgin, pregnant, and lactating mouse in the luminal population
con <- makeContrasts(
  L.PvsL = L.pregnant - L.lactating,
  L.VvsL = L.virgin - L.lactating,
  L.VvsP = L.virgin - L.pregnant, levels=design)
  
con 
  
res <- glmQLFTest(fit, contrast=con)
topTags(res)
is.de <- decideTests(res)
summary(is.de)

head(res$table)
#pdf("step08_Example_4_contrast_plot.pdf")
plotMD(res, status=is.de, values=c(1,0), col=c("maroon3","black"),
       legend="topright")
#dev.off()
#----------------------------

#other contrast examples: https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7873980/

#----------------------------
# 9. Save results in a table
#----------------------------
result <- as.data.frame( topTags(res, n = nrow(y$counts)) )
write.table(result, 
            file = "DE_result_handson.txt",
            quote = FALSE,
            sep = "\t",
            row.names = FALSE)


#-------------------------
# 10. Heatmap plots
#-------------------------

#Example 5: Hypothesis: The mean expression of L.lactating is different from the mean expression of L.virgin.
L.LvsV <- makeContrasts(L.lactating-L.virgin, levels=design)
res <- glmQLFTest(fit, contrast=L.LvsV )
topTags(res)
is.de <- decideTests(res)
summary(is.de)

# Extracting the top 50 genes
top_50_res_forHeatmap <- res$table %>% 
                            arrange(PValue) %>% 
                            as.data.frame %>% 
                            slice_head(n=50)
                            
                            
# Extracting the logCPM for the top 50 genes
top_50_cpm_forHeatmap <- cpm %>% 
                           as.data.frame(.) %>% 
                           filter(rownames(cpm) %in% rownames(top_50_res_forHeatmap))

# Formatting the gene names on the rows
ann_row <- y$genes %>% 
             as.data.frame(.) %>% 
              filter(rownames(y$genes) %in% rownames(top_50_cpm_forHeatmap))
rownames(ann_row) <- ann_row$Symbol
rownames(top_50_cpm_forHeatmap) <- rownames(ann_row)


# Optional: scale rows (genes) for better visualization
logcpm_scaled <- t(scale(t(top_50_cpm_forHeatmap)))

# Plot heatmap
#pdf("step10_Example_5_Heatmap_plot.pdf")
pheatmap(logcpm_scaled,
         cluster_rows = F,
         cluster_cols = F,
         show_rownames = TRUE,
         annotation_col = y$samples
         )
#dev.off()         
         
         
#save the session info
writeLines(capture.output(sessionInfo()), "sessionInfo.txt")

#-------------------------
